# KeepUp

A LibGDX Android football juggling prototype with a lightweight 2.5D perspective presentation.

## Gameplay prototype
- Tap near the bottom of the ball's bounce to juggle.
- The target foot can alternate or randomly stay on the same foot.
- Mistimed taps end the run.
- Score, best score (session), combo, and retry loop.

## Build
Requires JDK 17 and Android SDK (API 35).

```bash
gradle :android:assembleDebug
```

APK output: `android/build/outputs/apk/debug/android-debug.apk`

A GitHub Actions workflow is included at `.github/workflows/android.yml` and can build the APK after pushing this project to GitHub.
