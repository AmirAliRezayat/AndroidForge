package com.keepup.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class KeepUpGame extends ApplicationAdapter {
    private static final float W = 480, H = 800;
    private OrthographicCamera camera;
    private Viewport viewport;
    private ShapeRenderer shapes;
    private SpriteBatch batch;
    private BitmapFont font;
    private float phase, ballX, ballY, ballScale, feedbackTime, shakeTime;
    private int score, best, combo, targetFoot = 0;
    private boolean started, gameOver;
    private String feedback = "TAP TO START";
    private float time;

    @Override public void create() {
        camera = new OrthographicCamera();
        viewport = new FitViewport(W, H, camera);
        shapes = new ShapeRenderer();
        batch = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(1.7f);
        font.setColor(Color.WHITE);
        phase = 0.48f;
        ballX = footX();
    }

    @Override public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 1f / 30f);
        time += dt;
        if (feedbackTime > 0) feedbackTime -= dt;
        if (shakeTime > 0) shakeTime -= dt;
        if (started && !gameOver) updateGame(dt);
        handleInput();

        Gdx.gl.glClearColor(0.035f, 0.075f, 0.105f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        viewport.apply();
        camera.position.set(W / 2f, H / 2f, 0);
        if (shakeTime > 0) { camera.position.x += MathUtils.random(-4f, 4f); camera.position.y += MathUtils.random(-3f, 3f); }
        camera.update();
        shapes.setProjectionMatrix(camera.combined);
        batch.setProjectionMatrix(camera.combined);
        drawWorld();
        drawHud();
    }

    private void updateGame(float dt) {
        phase += dt * 0.92f;
        if (phase >= 1f) miss("TOO LATE!");
        float p = MathUtils.clamp(phase, 0, 1);
        float bounce = MathUtils.sin(p * MathUtils.PI);
        ballX = footX() + (targetFoot == 0 ? -1 : 1) * MathUtils.sin(p * MathUtils.PI) * 13f;
        ballY = 238 + bounce * 178;
        ballScale = 1f + bounce * 0.12f;
    }

    private void handleInput() {
        boolean pressed = Gdx.input.justTouched() || Gdx.input.isKeyJustPressed(Input.Keys.SPACE) || Gdx.input.isKeyJustPressed(Input.Keys.ENTER);
        if (!pressed) return;
        if (!started || gameOver) { startGame(); return; }
        if (phase >= 0.77f && phase <= 1f) {
            score++;
            combo++;
            best = Math.max(best, score);
            feedback = combo >= 5 ? "NICE COMBO!" : "PERFECT!";
            feedbackTime = 0.55f;
            float r = MathUtils.random();
            if (r < 0.34f) targetFoot = 1 - targetFoot;
            phase = 0.02f;
            ballY = 245;
        } else if (phase < 0.77f) {
            miss("BAD TIMING!");
        }
    }

    private void startGame() {
        started = true; gameOver = false; score = 0; combo = 0; phase = 0.42f;
        targetFoot = MathUtils.randomBoolean() ? 1 : 0;
        feedback = "KEEP IT UP!"; feedbackTime = 0.7f;
    }

    private void miss(String message) {
        gameOver = true; started = false; combo = 0; feedback = message; feedbackTime = 1.4f; shakeTime = 0.22f;
        ballX += targetFoot == 0 ? -105 : 105;
        ballY += 90;
    }

    private float footX() { return targetFoot == 0 ? 190 : 290; }

    private void drawWorld() {
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0.055f, 0.16f, 0.17f, 1); shapes.rect(0, 0, W, H);
        // Perspective pitch
        shapes.setColor(0.09f, 0.31f, 0.25f, 1);
        shapes.triangle(0, 0, W, 0, 405, 610);
        shapes.triangle(0, 0, 405, 610, 75, 610);
        shapes.setColor(0.11f, 0.36f, 0.28f, 1);
        for (int i = 0; i < 7; i++) {
            float y = i * 83;
            shapes.rect(0, y, W, 34, new Color(0.11f, 0.36f, 0.28f, 1), new Color(0.11f, 0.36f, 0.28f, 1), new Color(0.08f, 0.29f, 0.23f, 1), new Color(0.08f, 0.29f, 0.23f, 1));
        }
        shapes.end();

        shapes.begin(ShapeRenderer.ShapeType.Line);
        shapes.setColor(0.55f, 0.78f, 0.65f, 0.45f);
        shapes.ellipse(95, 105, 290, 105);
        shapes.line(240, 70, 240, 610);
        shapes.end();

        // Player legs and shoes, with slight depth offsets
        float leftLift = targetFoot == 0 && started ? MathUtils.sin(phase * MathUtils.PI) * 24 : 0;
        float rightLift = targetFoot == 1 && started ? MathUtils.sin(phase * MathUtils.PI) * 24 : 0;
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0, 0, 0, 0.25f); shapes.ellipse(112, 155, 256, 74);
        drawLeg(178, 105 + leftLift, false);
        drawLeg(302, 105 + rightLift, true);
        // ball shadow
        shapes.setColor(0, 0, 0, 0.32f); shapes.ellipse(ballX - 35, 214, 70, 20);
        // ball
        shapes.setColor(0.94f, 0.96f, 0.91f, 1); shapes.circle(ballX, ballY, 29 * ballScale, 32);
        shapes.setColor(0.08f, 0.12f, 0.15f, 1);
        for (int i = 0; i < 5; i++) {
            float a = i * MathUtils.PI2 / 5f + time * 1.5f;
            shapes.circle(ballX + MathUtils.cos(a) * 15 * ballScale, ballY + MathUtils.sin(a) * 15 * ballScale, 5.5f * ballScale, 6);
        }
        shapes.end();
    }

    private void drawLeg(float x, float y, boolean right) {
        shapes.setColor(0.16f, 0.22f, 0.32f, 1);
        shapes.rect(x - 24, y + 30, 48, 150);
        shapes.setColor(0.88f, 0.64f, 0.48f, 1);
        shapes.rect(x - 19, y + 155, 38, 35);
        shapes.setColor(0.12f, 0.15f, 0.21f, 1);
        shapes.rect(x - 26, y + 12, 52, 28);
        shapes.setColor(right ? 0.15f : 0.18f, right ? 0.55f : 0.68f, 0.92f, 1);
        shapes.ellipse(x - 39, y - 3, 78, 35);
        shapes.setColor(0.88f, 0.9f, 0.92f, 1);
        shapes.rectLine(x - 7, y + 3, x + 9, y + 3, 3);
    }

    private void drawHud() {
        batch.begin();
        font.setColor(0.65f, 0.82f, 0.95f, 1);
        font.draw(batch, "KEEPUP", 28, 760);
        font.setColor(Color.WHITE);
        font.draw(batch, "SCORE  " + score, 28, 710);
        font.draw(batch, "BEST  " + best, 330, 710);
        font.setColor(0.75f, 0.88f, 0.82f, 1);
        font.draw(batch, "COMBO  x" + combo, 28, 675);
        String foot = targetFoot == 0 ? "LEFT FOOT" : "RIGHT FOOT";
        font.draw(batch, foot, 180, 305);
        if (!started || feedbackTime > 0) {
            font.setColor(1f, 0.88f, 0.45f, 1);
            font.draw(batch, feedback, 150, 565);
        }
        if (gameOver) {
            font.setColor(Color.WHITE);
            font.draw(batch, "GAME OVER", 155, 495);
            font.setColor(0.72f, 0.84f, 0.92f, 1);
            font.draw(batch, "TAP TO RETRY", 155, 455);
        } else if (!started) {
            font.setColor(0.75f, 0.84f, 0.9f, 1);
            font.draw(batch, "TAP WHEN THE BALL REACHES YOUR FOOT", 42, 430);
        }
        batch.end();
    }

    @Override public void resize(int width, int height) { viewport.update(width, height, true); }
    @Override public void dispose() { shapes.dispose(); batch.dispose(); font.dispose(); }
}
