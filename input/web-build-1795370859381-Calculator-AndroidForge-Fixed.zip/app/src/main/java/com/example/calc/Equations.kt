package com.example.calc

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt

// ===================== چندجمله‌ای دو متغیره =====================
class EqError(msg: String) : Exception(msg)

class Poly(val t: Map<Pair<Int, Int>, Double>) {
    companion object {
        fun num(c: Double) = Poly(if (c == 0.0) emptyMap() else mapOf(Pair(0, 0) to c))
        fun variable(i: Int) = Poly(mapOf((if (i == 0) Pair(1, 0) else Pair(0, 1)) to 1.0))
    }

    val isConst: Boolean get() = t.keys.all { it == Pair(0, 0) }
    val constValue: Double get() = t[Pair(0, 0)] ?: 0.0

    operator fun plus(o: Poly): Poly {
        val m = t.toMutableMap()
        for ((k, v) in o.t) m[k] = (m[k] ?: 0.0) + v
        return Poly(m.filterValues { abs(it) > 1e-12 })
    }

    fun neg(): Poly = Poly(t.mapValues { -it.value })

    operator fun minus(o: Poly): Poly = this + o.neg()

    operator fun times(o: Poly): Poly {
        val m = HashMap<Pair<Int, Int>, Double>()
        for ((k1, v1) in t) {
            for ((k2, v2) in o.t) {
                val k = Pair(k1.first + k2.first, k1.second + k2.second)
                m[k] = (m[k] ?: 0.0) + v1 * v2
            }
        }
        return Poly(m.filterValues { abs(it) > 1e-12 })
    }

    fun div(d: Poly): Poly {
        if (!d.isConst) throw EqError("تقسیم بر مجهول پشتیبانی نمی‌شود")
        val dc = d.constValue
        if (dc == 0.0) throw EqError("تقسیم بر صفر")
        return Poly(t.mapValues { it.value / dc })
    }

    fun pow(n: Int): Poly {
        var r = num(1.0)
        repeat(n) { r = r * this }
        return r
    }
}

// ===================== پارسر =====================
class Parser(src: String, private val vars: List<Char>) {
    private val s = src.filter { !it.isWhitespace() }
    private var p = 0

    fun parseAll(): Poly {
        val r = expr()
        if (p < s.length) throw EqError("کاراکتر نامعتبر: ${s[p]}")
        return r
    }

    private fun peek(): Char? = if (p < s.length) s[p] else null

    private fun expr(): Poly {
        var r = term()
        var c = peek()
        while (c == '+' || c == '-') {
            p++
            val t = term()
            r = if (c == '+') r + t else r - t
            c = peek()
        }
        return r
    }

    private fun term(): Poly {
        var r = unary()
        while (true) {
            val c = peek() ?: break
            if (c == '*') {
                p++
                r = r * unary()
            } else if (c == '/') {
                p++
                r = r.div(unary())
            } else if (c.isLetter() || c.isDigit() || c == '.' || c == '(') {
                r = r * unary() // ضرب ضمنی مثل 2x یا 3(x+1)
            } else {
                break
            }
        }
        return r
    }

    private fun unary(): Poly {
        val c = peek()
        if (c == '-') {
            p++
            return unary().neg()
        }
        if (c == '+') {
            p++
            return unary()
        }
        return power()
    }

    private fun power(): Poly {
        val base = atom()
        if (peek() == '^') {
            p++
            val e = unary()
            if (!e.isConst) throw EqError("توان باید یک عدد باشد")
            val n = e.constValue
            if (n != floor(n) || n < 0 || n > 8) throw EqError("توان باید عدد صحیح بین ۰ تا ۸ باشد")
            return base.pow(n.toInt())
        }
        return base
    }

    private fun atom(): Poly {
        val c = peek() ?: throw EqError("عبارت ناقص است")
        if (c == '(') {
            p++
            val r = expr()
            if (peek() != ')') throw EqError("پرانتز بسته نشده")
            p++
            return r
        }
        if (c.isDigit() || c == '.') {
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            val v = s.substring(st, p).toDoubleOrNull() ?: throw EqError("عدد نامعتبر")
            return Poly.num(v)
        }
        if (c.isLetter()) {
            val i = vars.indexOf(c)
            if (i < 0) throw EqError("متغیر نامعتبر: $c")
            p++
            return Poly.variable(i)
        }
        throw EqError("کاراکتر نامعتبر: $c")
    }
}

fun normalizeEq(s: String): String =
    normalizeDigits(s).replace('−', '-').replace('×', '*').replace('÷', '/').replace('،', ' ')

fun lettersOf(text: String): List<Char> =
    text.filter { it in 'a'..'z' || it in 'A'..'Z' }.toList().distinct().sorted()

fun parseEq(text: String, vars: List<Char>): Poly {
    val parts = normalizeEq(text).split("=")
    if (parts.size != 2) throw EqError("معادله باید دقیقاً یک علامت = داشته باشد")
    if (parts[0].isBlank() || parts[1].isBlank()) throw EqError("دو طرف معادله را کامل بنویسید")
    return Parser(parts[0], vars).parseAll() - Parser(parts[1], vars).parseAll()
}

// ===================== حل‌کننده‌ها =====================
private const val EPS = 1e-9

fun toFraction(d: Double): String? {
    if (d == Math.rint(d)) return null
    val x = abs(d)
    for (q in 2..1000) {
        val p = Math.round(x * q)
        if (abs(x - p.toDouble() / q) < 1e-9) return (if (d < 0) "-" else "") + "$p/$q"
    }
    return null
}

fun showNum(d: Double): String {
    val f = groupDigits(formatDouble(d))
    val fr = toFraction(d)
    return if (fr != null) "$fr ≈ $f" else f
}

fun solveOne(text: String): List<String> {
    val vars = lettersOf(normalizeEq(text))
    if (vars.isEmpty()) throw EqError("مجهولی مثل x در معادله نیست")
    if (vars.size > 1) throw EqError("این بخش فقط یک مجهول دارد. از بخش «دو مجهولی» استفاده کنید")
    val v = vars[0]
    val f = parseEq(text, vars)

    val c = DoubleArray(65)
    var deg = 0
    for ((k, value) in f.t) {
        if (k.first >= c.size) throw EqError("درجه معادله خیلی بالاست")
        if (abs(value) > 1e-12) {
            c[k.first] = value
            if (k.first > deg) deg = k.first
        }
    }

    return when (deg) {
        0 -> if (abs(c[0]) < EPS) listOf("بی‌نهایت جواب دارد (همیشه درست است)") else listOf("جواب ندارد")
        1 -> listOf("$v = ${showNum(-c[0] / c[1])}")
        2 -> {
            val a = c[2]
            val b = c[1]
            val cc = c[0]
            val d = b * b - 4 * a * cc
            val res = mutableListOf("Δ = ${showNum(d)}")
            if (abs(d) < EPS) {
                res.add("$v = ${showNum(-b / (2 * a))}")
            } else if (d > 0) {
                res.add("${v}₁ = ${showNum((-b + sqrt(d)) / (2 * a))}")
                res.add("${v}₂ = ${showNum((-b - sqrt(d)) / (2 * a))}")
            } else {
                val re = -b / (2 * a)
                val im = abs(sqrt(-d) / (2 * a))
                res.add("ریشه حقیقی ندارد")
                res.add("$v = ${showNum(re)} ± ${showNum(im)}i")
            }
            res
        }
        else -> throw EqError("فقط معادلات تا درجه ۲ پشتیبانی می‌شوند")
    }
}

fun solveTwo(t1: String, t2: String): List<String> {
    val vars = lettersOf(normalizeEq(t1) + normalizeEq(t2))
    if (vars.size < 2) throw EqError("دو مجهول لازم است (مثلاً x و y)")
    if (vars.size > 2) throw EqError("بیشتر از دو مجهول پشتیبانی نمی‌شود")
    val f1 = parseEq(t1, vars)
    val f2 = parseEq(t2, vars)

    fun coeffs(f: Poly): Triple<Double, Double, Double> {
        var a = 0.0
        var b = 0.0
        var c = 0.0
        for ((k, v) in f.t) {
            if (abs(v) < 1e-12) continue
            when {
                k == Pair(1, 0) -> a = v
                k == Pair(0, 1) -> b = v
                k == Pair(0, 0) -> c = v
                else -> throw EqError("فقط معادلات خطی پشتیبانی می‌شوند (بدون توان یا xy)")
            }
        }
        return Triple(a, b, c)
    }

    val (a1, b1, c1) = coeffs(f1)
    val (a2, b2, c2) = coeffs(f2)
    val r1 = -c1
    val r2 = -c2
    val d = a1 * b2 - a2 * b1
    val dx = r1 * b2 - r2 * b1
    val dy = a1 * r2 - a2 * r1

    if (abs(d) > EPS) {
        return listOf("${vars[0]} = ${showNum(dx / d)}", "${vars[1]} = ${showNum(dy / d)}")
    }
    val bad1 = abs(a1) < EPS && abs(b1) < EPS && abs(r1) > EPS
    val bad2 = abs(a2) < EPS && abs(b2) < EPS && abs(r2) > EPS
    return if (bad1 || bad2 || abs(dx) > EPS || abs(dy) > EPS) {
        listOf("جواب ندارد (دستگاه ناسازگار است)")
    } else {
        listOf("بی‌نهایت جواب دارد")
    }
}

// ===================== رابط کاربری =====================
@Composable
fun EqField(
    label: String,
    hint: String,
    value: String,
    onChange: (String) -> Unit,
    onFocus: () -> Unit
) {
    Column {
        Text(label, color = Muted, fontSize = 13.sp)
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(PanelBg)
                .padding(16.dp)
        ) {
            if (value.isEmpty()) Text(hint, color = Muted, fontSize = 22.sp)
            BasicTextField(
                value = value,
                onValueChange = onChange,
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 24.sp,
                    textDirection = TextDirection.Ltr
                ),
                singleLine = true,
                cursorBrush = SolidColor(Orange),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { if (it.isFocused) onFocus() }
            )
        }
    }
}

@Composable
fun EquationScreen(onBack: () -> Unit) {
    var mode by rememberSaveable { mutableStateOf(0) }
    var eq1 by rememberSaveable { mutableStateOf("") }
    var eq2 by rememberSaveable { mutableStateOf("") }
    var focus by remember { mutableIntStateOf(0) }
    var lines by remember { mutableStateOf<List<String>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    fun insert(s: String) {
        if (focus == 1 && mode == 1) eq2 += s else eq1 += s
    }

    fun solve() {
        try {
            lines = if (mode == 0) solveOne(eq1) else solveTwo(eq1, eq2)
            error = null
        } catch (e: Exception) {
            lines = emptyList()
            error = e.message ?: "خطا در حل معادله"
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("معادله", onBack)

        SegmentedTabs(listOf("یک مجهولی", "دو مجهولی"), mode) {
            mode = it
            lines = emptyList()
            error = null
        }

        EqField(
            if (mode == 0) "معادله" else "معادله اول",
            if (mode == 0) "مثال: 2x+3=11" else "مثال: 2x+y=10",
            eq1, { eq1 = it }, { focus = 0 }
        )
        if (mode == 1) {
            EqField("معادله دوم", "مثال: x-y=2", eq2, { eq2 = it }, { focus = 1 })
        }

        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val symbols = if (mode == 0) {
                listOf("x", "^", "(", ")", "=", "+", "−", "×", "÷", ".")
            } else {
                listOf("x", "y", "^", "(", ")", "=", "+", "−", "×", "÷", ".")
            }
            symbols.forEach { s -> Chip(s, false) { insert(s) } }
        }

        Text("مثال‌ها", color = Muted, fontSize = 13.sp)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (mode == 0) {
                listOf("2x+3=11", "3(x-2)=x+8", "x^2-5x+6=0").forEach { ex ->
                    Chip(ex, false) { eq1 = ex }
                }
            } else {
                listOf("2x+y=10" to "x-y=2", "x+y=7" to "2x-y=2").forEach { (a, b) ->
                    Chip("$a  |  $b", false) {
                        eq1 = a
                        eq2 = b
                    }
                }
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(50))
                .background(Orange)
                .clickable { solve() }
                .padding(vertical = 15.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("حل کن", color = Color.White, fontSize = 20.sp)
        }

        if (lines.isNotEmpty() || error != null) {
            Panel {
                Text("نتیجه", color = Muted, fontSize = 13.sp)
                val err = error
                if (err != null) {
                    Text(err, color = ErrorRed, fontSize = 18.sp)
                } else {
                    lines.forEach { l ->
                        Text(
                            l,
                            color = Color.White,
                            fontSize = 22.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
