package com.example.calc

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.abs
import kotlin.math.floor

/** 100000 -> 100,000   |   -1234.5 -> -1,234.5   |   "12." -> "12." */
fun groupDigits(s: String): String {
    if (s == "Error" || s.contains('E')) return s
    val neg = s.startsWith("-")
    val body = if (neg) s.drop(1) else s
    val intPart = body.substringBefore('.')
    val rest = if (body.contains('.')) "." + body.substringAfter('.') else ""
    val grouped = intPart.reversed().chunked(3).joinToString(",").reversed()
    return (if (neg) "-" else "") + grouped + rest
}

/** عدد را به رشته تمیز (بدون خطای اعشاری) تبدیل می‌کند. */
fun formatDouble(r: Double): String {
    if (r.isNaN() || r.isInfinite()) return "Error"
    if (r == 0.0) return "0"
    if (r == floor(r) && abs(r) < 1e15) return r.toLong().toString()
    val bd = BigDecimal(r).round(MathContext(10)).stripTrailingZeros()
    val a = abs(r)
    return if (a >= 1e15 || a < 1e-9) bd.toString() else bd.toPlainString()
}

/** ارقام فارسی و عربی را به لاتین تبدیل می‌کند. */
fun normalizeDigits(s: String): String = buildString {
    for (c in s) {
        append(
            when (c) {
                in '۰'..'۹' -> '0' + (c - '۰')
                in '٠'..'٩' -> '0' + (c - '٠')
                '٫' -> '.'
                else -> c
            }
        )
    }
}
