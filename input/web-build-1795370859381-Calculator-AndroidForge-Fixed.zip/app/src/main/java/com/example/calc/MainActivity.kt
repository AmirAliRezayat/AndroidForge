package com.example.calc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    var screen by rememberSaveable { mutableStateOf(0) }
    BackHandler(enabled = screen != 0) { screen = 0 }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .systemBarsPadding()
    ) {
        when (screen) {
            0 -> CalculatorScreen(onUnits = { screen = 1 }, onEquations = { screen = 2 })
            1 -> CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                ConverterScreen(onBack = { screen = 0 })
            }
            else -> CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                EquationScreen(onBack = { screen = 0 })
            }
        }
    }
}

@Composable
fun CalculatorScreen(
    onUnits: () -> Unit,
    onEquations: () -> Unit,
    vm: CalcViewModel = viewModel()
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            val gap = 12.dp
            val size = (maxWidth - gap * 3) / 4

            Column(Modifier.fillMaxSize()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("⇄  تبدیل واحد", false, onUnits)
                    Chip("x=  معادله", false, onEquations)
                }
                Spacer(Modifier.weight(1f))

                val evaluated = vm.evaluated
                val topText = if (evaluated) vm.historyText else vm.expressionText.ifEmpty { "0" }
                val bottomText = if (evaluated) groupDigits(vm.resultRaw) else (vm.preview ?: "")
                val topTarget = if (evaluated) 24f else when {
                    topText.length <= 7 -> 72f
                    topText.length <= 10 -> 60f
                    topText.length <= 14 -> 48f
                    topText.length <= 20 -> 38f
                    else -> 30f
                }
                val bottomTarget = if (evaluated) when {
                    bottomText.length <= 7 -> 88f
                    bottomText.length <= 9 -> 72f
                    bottomText.length <= 12 -> 56f
                    else -> 44f
                } else 30f
                val topSize by animateFloatAsState(topTarget, label = "topSize")
                val bottomSize by animateFloatAsState(bottomTarget, label = "bottomSize")
                val topColor by animateColorAsState(if (evaluated) Muted else Color.White, label = "topColor")
                val bottomColor by animateColorAsState(if (evaluated) Color.White else Muted, label = "bottomColor")

                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .pointerInput(Unit) {
                            var total = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { total = 0f },
                                onDragEnd = { if (abs(total) > 40f) vm.backspace() }
                            ) { _, dragAmount -> total += dragAmount }
                        }
                ) {
                    Text(
                        text = topText,
                        color = topColor,
                        fontSize = topSize.sp,
                        fontWeight = FontWeight.Light,
                        maxLines = 2,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = bottomText,
                        color = bottomColor,
                        fontSize = bottomSize.sp,
                        fontWeight = FontWeight.Light,
                        maxLines = 1,
                        softWrap = false,
                        textAlign = TextAlign.End,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 40.dp)
                    )
                }
                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    CalcButton("AC", size, LightGray, Color.Black) { vm.clear() }
                    CalcButton("±", size, LightGray, Color.Black) { vm.negate() }
                    CalcButton("%", size, LightGray, Color.Black) { vm.percent() }
                    OpButton("÷", size, vm)
                }
                Spacer(Modifier.height(gap))
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    listOf("7", "8", "9").forEach { d -> CalcButton(d, size) { vm.digit(d) } }
                    OpButton("×", size, vm)
                }
                Spacer(Modifier.height(gap))
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    listOf("4", "5", "6").forEach { d -> CalcButton(d, size) { vm.digit(d) } }
                    OpButton("−", size, vm)
                }
                Spacer(Modifier.height(gap))
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    listOf("1", "2", "3").forEach { d -> CalcButton(d, size) { vm.digit(d) } }
                    OpButton("+", size, vm)
                }
                Spacer(Modifier.height(gap))
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    CalcButton("0", size, width = size * 2 + gap, pill = true) { vm.digit("0") }
                    CalcButton(".", size) { vm.dot() }
                    CalcButton("=", size, Orange, Color.White) { vm.onEquals() }
                }
            }
        }
    }
}

@Composable
fun OpButton(symbol: String, size: Dp, vm: CalcViewModel) {
    val active = vm.activeOp == symbol
    CalcButton(
        symbol, size,
        bg = if (active) Color.White else Orange,
        fg = if (active) Orange else Color.White
    ) { vm.operator(symbol) }
}

@Composable
fun CalcButton(
    label: String,
    size: Dp,
    bg: Color = DarkGray,
    fg: Color = Color.White,
    width: Dp = size,
    pill: Boolean = false,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val haptic = LocalHapticFeedback.current
    val shown = if (pressed) lerp(bg, Color.White, 0.28f) else bg

    Box(
        modifier = Modifier
            .size(width, size)
            .clip(if (pill) RoundedCornerShape(size / 2) else CircleShape)
            .background(shown)
            .clickable(interactionSource = source, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = if (pill) Alignment.CenterStart else Alignment.Center
    ) {
        Text(
            label,
            color = fg,
            fontSize = 36.sp,
            modifier = if (pill) Modifier.padding(start = size / 2.6f) else Modifier
        )
    }
}
