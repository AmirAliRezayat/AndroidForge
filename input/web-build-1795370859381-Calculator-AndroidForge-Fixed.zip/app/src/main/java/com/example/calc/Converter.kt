package com.example.calc

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- داده‌ها ----------
class UnitDef(val name: String, val toBase: (Double) -> Double, val fromBase: (Double) -> Double)

fun lin(name: String, f: Double) = UnitDef(name, { it * f }, { it / f })

class Category(val title: String, val units: List<UnitDef>, val defFrom: Int = 0, val defTo: Int = 1)

val categories: List<Category> = listOf(
    Category(
        "طول", listOf(
            lin("نانومتر (nm)", 1e-9), lin("میکرومتر (µm)", 1e-6), lin("میلی‌متر (mm)", 1e-3),
            lin("سانتی‌متر (cm)", 1e-2), lin("متر (m)", 1.0), lin("کیلومتر (km)", 1e3),
            lin("مگامتر (Mm)", 1e6), lin("اینچ (in)", 0.0254), lin("فوت (ft)", 0.3048),
            lin("یارد (yd)", 0.9144), lin("مایل (mi)", 1609.344), lin("مایل دریایی", 1852.0)
        ), 4, 5
    ),
    Category(
        "جرم", listOf(
            lin("میکروگرم (µg)", 1e-9), lin("میلی‌گرم (mg)", 1e-6), lin("گرم (g)", 1e-3),
            lin("کیلوگرم (kg)", 1.0), lin("تن (t)", 1e3), lin("مگاگرم (Mg)", 1e3),
            lin("اونس (oz)", 0.028349523125), lin("پوند (lb)", 0.45359237)
        ), 3, 2
    ),
    Category(
        "حجم", listOf(
            lin("میکرولیتر (µL)", 1e-6), lin("میلی‌لیتر (mL)", 1e-3), lin("سانتی‌لیتر (cL)", 1e-2),
            lin("لیتر (L)", 1.0), lin("کیلولیتر (kL)", 1e3), lin("مگالیتر (ML)", 1e6),
            lin("سانتی‌متر مکعب (cm³)", 1e-3), lin("متر مکعب (m³)", 1e3),
            lin("گالن آمریکا", 3.785411784), lin("گالن انگلیس", 4.54609),
            lin("کوارت آمریکا", 0.946352946), lin("پینت آمریکا", 0.473176473),
            lin("فنجان (cup)", 0.2365882365), lin("قاشق غذاخوری", 0.01478676478)
        ), 3, 1
    ),
    Category(
        "مساحت", listOf(
            lin("میلی‌متر مربع (mm²)", 1e-6), lin("سانتی‌متر مربع (cm²)", 1e-4),
            lin("متر مربع (m²)", 1.0), lin("هکتار (ha)", 1e4), lin("کیلومتر مربع (km²)", 1e6),
            lin("اینچ مربع (in²)", 0.00064516), lin("فوت مربع (ft²)", 0.09290304),
            lin("ایکر (acre)", 4046.8564224), lin("مایل مربع (mi²)", 2589988.110336)
        ), 2, 3
    ),
    Category(
        "سرعت", listOf(
            lin("متر بر ثانیه (m/s)", 1.0), lin("کیلومتر بر ساعت (km/h)", 1.0 / 3.6),
            lin("مایل بر ساعت (mph)", 0.44704), lin("گره دریایی (knot)", 1852.0 / 3600.0),
            lin("فوت بر ثانیه (ft/s)", 0.3048), lin("ماخ (Mach)", 340.29)
        ), 1, 0
    ),
    Category(
        "زمان", listOf(
            lin("میکروثانیه (µs)", 1e-6), lin("میلی‌ثانیه (ms)", 1e-3), lin("ثانیه (s)", 1.0),
            lin("دقیقه (min)", 60.0), lin("ساعت (h)", 3600.0), lin("روز", 86400.0),
            lin("هفته", 604800.0), lin("ماه (۳۰ روز)", 2592000.0), lin("سال (۳۶۵ روز)", 31536000.0)
        ), 4, 3
    ),
    Category(
        "دما", listOf(
            UnitDef("سانتی‌گراد (°C)", { it }, { it }),
            UnitDef("فارنهایت (°F)", { (it - 32.0) * 5.0 / 9.0 }, { it * 9.0 / 5.0 + 32.0 }),
            UnitDef("کلوین (K)", { it - 273.15 }, { it + 273.15 })
        ), 0, 1
    ),
    Category(
        "داده", listOf(
            lin("بیت (bit)", 0.125), lin("بایت (B)", 1.0), lin("کیلوبایت (KB)", 1024.0),
            lin("مگابایت (MB)", 1048576.0), lin("گیگابایت (GB)", 1073741824.0),
            lin("ترابایت (TB)", 1099511627776.0), lin("پتابایت (PB)", 1125899906842624.0)
        ), 3, 2
    ),
    Category(
        "انرژی", listOf(
            lin("ژول (J)", 1.0), lin("کیلوژول (kJ)", 1e3), lin("مگاژول (MJ)", 1e6),
            lin("کالری (cal)", 4.184), lin("کیلوکالری (kcal)", 4184.0),
            lin("وات‌ساعت (Wh)", 3600.0), lin("کیلووات‌ساعت (kWh)", 3.6e6), lin("BTU", 1055.05585)
        ), 4, 1
    ),
    Category(
        "فشار", listOf(
            lin("پاسکال (Pa)", 1.0), lin("کیلوپاسکال (kPa)", 1e3), lin("مگاپاسکال (MPa)", 1e6),
            lin("بار (bar)", 1e5), lin("اتمسفر (atm)", 101325.0),
            lin("پوند بر اینچ مربع (psi)", 6894.757293), lin("میلی‌متر جیوه (mmHg)", 133.322387)
        ), 3, 5
    ),
    Category(
        "توان", listOf(
            lin("وات (W)", 1.0), lin("کیلووات (kW)", 1e3), lin("مگاوات (MW)", 1e6),
            lin("اسب بخار (hp)", 745.69987)
        ), 1, 3
    ),
    Category(
        "پیشوند SI", listOf(
            lin("پیکو (p)", 1e-12), lin("نانو (n)", 1e-9), lin("میکرو (µ)", 1e-6),
            lin("میلی (m)", 1e-3), lin("سانتی (c)", 1e-2), lin("واحد (۱)", 1.0),
            lin("کیلو (k)", 1e3), lin("مگا (M)", 1e6), lin("گیگا (G)", 1e9), lin("ترا (T)", 1e12)
        ), 5, 6
    )
)

// ---------- صفحه تبدیل واحد ----------
@Composable
fun ConverterScreen(onBack: () -> Unit) {
    var catIdx by rememberSaveable { mutableStateOf(0) }
    var fromIdx by rememberSaveable { mutableStateOf(categories[0].defFrom) }
    var toIdx by rememberSaveable { mutableStateOf(categories[0].defTo) }
    var input by rememberSaveable { mutableStateOf("1") }

    val cat = categories[catIdx]
    val from = cat.units[fromIdx]
    val to = cat.units[toIdx]
    val x = input.toDoubleOrNull()
    val base = if (x == null) null else from.toBase(x)

    fun conv(u: UnitDef): String =
        if (base == null) "—" else groupDigits(formatDouble(u.fromBase(base)))

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("تبدیل واحد", onBack)

        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEachIndexed { i, c ->
                Chip(c.title, i == catIdx) {
                    catIdx = i
                    fromIdx = c.defFrom
                    toIdx = c.defTo
                }
            }
        }

        Panel {
            Text("از", color = Muted, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = input,
                    onValueChange = { raw ->
                        val s = normalizeDigits(raw)
                        if (s.isEmpty() || Regex("-?\\d*\\.?\\d*").matches(s)) input = s
                    },
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 32.sp,
                        textDirection = TextDirection.Ltr
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    cursorBrush = SolidColor(Orange),
                    modifier = Modifier.weight(1f)
                )
                Chip("±", false) {
                    input = if (input.startsWith("-")) input.drop(1) else "-$input"
                }
                UnitPicker(cat.units, fromIdx) { fromIdx = it }
            }
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Chip("⇅  جابجایی", false) {
                if (base != null) input = formatDouble(to.fromBase(base))
                val t = fromIdx
                fromIdx = toIdx
                toIdx = t
            }
        }

        Panel {
            Text("به", color = Muted, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    conv(to),
                    color = Color.White,
                    fontSize = 32.sp,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.weight(1f)
                )
                UnitPicker(cat.units, toIdx) { toIdx = it }
            }
        }

        Text("همه واحدها", color = Muted, fontSize = 13.sp)
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(cat.units) { i, u ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { toIdx = i }
                        .padding(vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        u.name,
                        color = if (i == toIdx) Orange else Color.White,
                        fontSize = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        conv(u),
                        color = if (i == toIdx) Orange else Color.White,
                        fontSize = 16.sp,
                        maxLines = 1,
                        softWrap = false
                    )
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0xFF2C2C2E))
                )
            }
        }
    }
}

@Composable
fun UnitPicker(units: List<UnitDef>, selected: Int, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Text(
            units[selected].name + " ▾",
            color = Orange,
            fontSize = 15.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable { open = true }
                .padding(8.dp)
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            units.forEachIndexed { i, u ->
                DropdownMenuItem(
                    text = { Text(u.name) },
                    onClick = {
                        onSelect(i)
                        open = false
                    }
                )
            }
        }
    }
}
