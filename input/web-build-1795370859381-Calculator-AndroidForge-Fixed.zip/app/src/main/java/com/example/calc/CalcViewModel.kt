package com.example.calc

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

/**
 * ماشین حساب مبتنی بر عبارت کامل:
 * عبارت مثل «55 × 104» نوشته می‌شود و نتیجه‌ی زنده زیرش با فونت کوچک دیده می‌شود.
 * با زدن «=» نتیجه بزرگ می‌شود و عبارت کوچک می‌رود بالا.
 */
class CalcViewModel : ViewModel() {
    // توکن‌ها: عدد، عملگر، عدد، ... (عدد می‌تواند با % تمام شود یا با - شروع شود)
    private var tokens by mutableStateOf<List<String>>(emptyList())

    var evaluated by mutableStateOf(false); private set
    var historyText by mutableStateOf(""); private set
    var resultRaw by mutableStateOf("0"); private set

    private var repeatOp: Pair<String, String>? = null

    private fun isOp(t: String) = t == "+" || t == "−" || t == "×" || t == "÷"

    private fun cleaned(): List<String> {
        val last = tokens.lastOrNull()
        return if (last != null && isOp(last)) tokens.dropLast(1) else tokens
    }

    // ---------- چیزهایی که UI می‌خواند ----------
    val expressionText: String get() = formatTokens(tokens)

    val preview: String?
        get() {
            if (evaluated) return null
            val t = cleaned()
            if (t.size < 3 && !(t.size == 1 && t[0].endsWith("%"))) return null
            val v = evaluate(t)
            if (v.isNaN() || v.isInfinite()) return null
            return groupDigits(formatDouble(v))
        }

    val activeOp: String?
        get() = if (evaluated) null else tokens.lastOrNull()?.takeIf { isOp(it) }

    // ---------- ورودی‌ها ----------
    private fun startNew() {
        tokens = emptyList()
        evaluated = false
        historyText = ""
    }

    fun digit(d: String) {
        if (evaluated) startNew()
        val last = tokens.lastOrNull()
        if (last == null || isOp(last)) {
            tokens = tokens + d
            return
        }
        if (last.endsWith("%")) return
        val digits = last.count { it.isDigit() }
        val newLast = when {
            last == "0" -> d
            last == "-0" -> "-$d"
            digits >= 12 -> last
            else -> last + d
        }
        tokens = tokens.dropLast(1) + newLast
    }

    fun dot() {
        if (evaluated) startNew()
        val last = tokens.lastOrNull()
        if (last == null || isOp(last)) {
            tokens = tokens + "0."
            return
        }
        if (last.endsWith("%") || last.contains('.')) return
        tokens = tokens.dropLast(1) + (last + ".")
    }

    fun operator(o: String) {
        if (evaluated) {
            evaluated = false
            historyText = ""
            if (tokens.isEmpty()) return // بعد از Error
        }
        val last = tokens.lastOrNull()
        tokens = when {
            last == null -> listOf("0", o)
            isOp(last) -> tokens.dropLast(1) + o
            else -> tokens + o
        }
    }

    fun onEquals() {
        if (evaluated) {
            repeatLast()
            return
        }
        val t = cleaned()
        if (t.size < 3 && !(t.size == 1 && t[0].endsWith("%"))) return
        val v = evaluate(t)
        repeatOp = if (t.size >= 3) Pair(t[t.size - 2], t.last()) else null
        finish(t, v)
    }

    private fun repeatLast() {
        val r = repeatOp ?: return
        if (tokens.isEmpty()) return
        val t = listOf(tokens[0], r.first, r.second)
        finish(t, evaluate(t))
    }

    private fun finish(t: List<String>, v: Double) {
        historyText = formatTokens(t) + " ="
        resultRaw = formatDouble(v)
        evaluated = true
        tokens = if (resultRaw == "Error") emptyList() else listOf(resultRaw)
    }

    fun clear() {
        tokens = emptyList()
        evaluated = false
        historyText = ""
        resultRaw = "0"
        repeatOp = null
    }

    fun negate() {
        if (evaluated) {
            evaluated = false
            historyText = ""
        }
        val last = tokens.lastOrNull() ?: return
        if (isOp(last)) return
        val n = if (last.startsWith("-")) last.drop(1) else "-$last"
        tokens = tokens.dropLast(1) + n
    }

    fun percent() {
        if (evaluated) {
            evaluated = false
            historyText = ""
        }
        val last = tokens.lastOrNull() ?: return
        if (isOp(last) || last.endsWith("%")) return
        tokens = tokens.dropLast(1) + (last + "%")
    }

    fun backspace() {
        if (evaluated) return
        val last = tokens.lastOrNull() ?: return
        if (isOp(last)) {
            tokens = tokens.dropLast(1)
            return
        }
        val n = last.dropLast(1)
        tokens = if (n.isEmpty() || n == "-") tokens.dropLast(1) else tokens.dropLast(1) + n
    }

    // ---------- محاسبه ----------
    private fun tokenValue(t: String): Double {
        val pct = t.endsWith("%")
        val v = t.removeSuffix("%").toDoubleOrNull() ?: 0.0
        return if (pct) v / 100 else v
    }

    /** t: عدد op عدد op ... (بدون عملگر آخر). اولویت × و ÷ بر + و − رعایت می‌شود. */
    private fun evaluate(t: List<String>): Double {
        val nums = ArrayList<Double>()
        val ops = ArrayList<String>()
        for ((i, s) in t.withIndex()) {
            if (i % 2 == 0) {
                var v = tokenValue(s)
                // 100 + 10%  ->  100 + (10% از 100)
                if (s.endsWith("%") && i >= 2 && (t[i - 1] == "+" || t[i - 1] == "−")) {
                    v *= evaluate(t.subList(0, i - 1))
                }
                nums.add(v)
            } else {
                ops.add(s)
            }
        }
        val n2 = ArrayList<Double>()
        val o2 = ArrayList<String>()
        n2.add(nums[0])
        for (k in ops.indices) {
            val v = nums[k + 1]
            when (ops[k]) {
                "×" -> n2[n2.size - 1] = n2[n2.size - 1] * v
                "÷" -> n2[n2.size - 1] = if (v == 0.0) Double.NaN else n2[n2.size - 1] / v
                else -> {
                    o2.add(ops[k])
                    n2.add(v)
                }
            }
        }
        var r = n2[0]
        for (k in o2.indices) r = if (o2[k] == "+") r + n2[k + 1] else r - n2[k + 1]
        return r
    }

    private fun formatTokens(t: List<String>): String =
        t.mapIndexed { i, s ->
            if (isOp(s)) {
                s
            } else {
                val core = s.removeSuffix("%")
                var g = groupDigits(core)
                if (s.endsWith("%")) g += "%"
                if (i > 0 && core.startsWith("-")) "($g)" else g
            }
        }.joinToString(" ")
}
