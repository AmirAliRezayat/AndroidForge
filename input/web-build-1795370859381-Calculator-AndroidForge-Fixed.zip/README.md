# ماشین حساب اندروید | Amirali Rezayat

پروژه Kotlin + Jetpack Compose با خروجی APK از طریق GitHub Actions.

## ساخت APK

1. یک repository در GitHub بسازید (برای کلید امضا حتماً **Private** باشد).
2. محتویات همین پوشه را در ریشه repository آپلود کنید؛ پوشه `.github` هم باید آپلود شود.
3. از تب **Actions**، اجرای `Build APK` را باز کنید.
4. پس از پایان موفق، از بخش Artifacts فایل `calculator-debug-apk` را برای تست دانلود کنید.

## ساخت کلید امضای اختصاصی (فقط یک بار)

1. در repository خصوصی، وارد **Actions** شوید.
2. workflow با نام `Create release signing key (run once)` را انتخاب و روی **Run workflow** بزنید.
3. پس از پایان، artifact با نام `private-signing-materials` را دانلود و از حالت فشرده خارج کنید.
4. فایل `secrets.txt` شامل سه مقدار رمز و alias و مقدار Base64 کلید است. این فایل و `release.jks` را محرمانه نگه دارید.
5. در GitHub به **Settings → Secrets and variables → Actions → New repository secret** بروید و این چهار Secret را بسازید:
   - `KEYSTORE_BASE64`: تمام محتوای بخش بعد از `KEYSTORE_BASE64=` در `secrets.txt` (یک رشته طولانی Base64)
   - `KEYSTORE_PASSWORD`: مقدار `KEYSTORE_PASSWORD`
   - `KEY_PASSWORD`: مقدار `KEY_PASSWORD`
   - `KEY_ALIAS`: مقدار `KEY_ALIAS`
6. پس از ثبت Secretها، artifact و فایل‌های دانلودشده را در محل امن نگهداری کنید و از دستگاه‌های عمومی پاک کنید.

## ساخت نسخه امضاشده برای انتشار

بعد از افزودن چهار Secret، در **Actions → Build APK → Run workflow** اجرا کنید.
در صورت موفقیت، artifact با نام `calculator-signed-release-apk` شامل `app-release.apk` امضاشده خواهد بود.

## نکات مهم

- کلید امضا را گم نکنید؛ برای انتشار به‌روزرسانی‌های همین برنامه باید از همان کلید استفاده شود.
- workflow ساخت کلید را فقط یک بار اجرا کنید. اجرای دوباره، کلید جدیدی می‌سازد و با نسخه قبلی سازگار نیست.
- کلید یا رمزها را در کد، Git یا repository عمومی قرار ندهید.
- نام `Amirali Rezayat` در مشخصات گواهی امضا ثبت می‌شود؛ این نام به‌تنهایی هویت حقوقی صاحب برنامه را تأیید نمی‌کند.
- خروجی نهایی این بسته APK است؛ برای انتشار در Google Play ممکن است فرمت AAB و الزامات هدف‌گیری API جداگانه لازم باشد.
